const GetSearchResults = {
    describe: 'User want to do search with custom keyword',
    positive: {
      getSearchByKeyword: 'As a User, I want to be able to do search'
    },
    negative: {
      
    }
  };
  
  module.exports = {
    GetSearchResults
  }